import React, { Component } from 'react'
import CurrencyConverter from './CurrencyConverter'
import './css/Home.css'

 class Home extends Component {
    constructor(props){
        super(props)
        this.state = {
            apiKey:'',
            showComponent:false,
            checkKey:false
        }
    }

    onChangeHandler = (event) =>{
        this.setState({
            apiKey: event.target.value
        })
    }

    clickHandler = ()=>{
        if(!this.state.apiKey){
            this.setState({
                checkKey: true,
              });
        }
        else{
            this.setState({
                showComponent: true,
              });
        }
    }
    render() {
        return (
            <React.Fragment> 
                {this.state.showComponent ? <CurrencyConverter apiKey={this.state.apiKey} /> : 
                    <div className="center">
                        <h2>Currency Conversion</h2>
                        <div className="form">
                            <label>Please enter currency converter API key</label>
                            <input type="api" id="apikey" placeholder="Enter API KEY" onChange={this.onChangeHandler} />
                            <button type="submit" onClick={this.clickHandler}>Submit</button>
                        </div>
                        {this.state.checkKey ? <label className="error">Please enter valid API key</label> : ''}
                    </div>
                }
            </React.Fragment>
        )
    }
}

export default Home
