Please unzip the project the Currency-Convereter project 

Please cd to Currency-Conveter project folder

Please run 'npm install' command. This will help you to install all the dependencies to run the application.

Please start the project with help of 'npm start' command. It will run automatically in the localhost.

Here i have user api calls to get currency type as well as converted amount.

Please go components folder for Home and CurrencyConverter functionality.

I have implemented responsive with help of css. You can find css files in the component/css folder.

Please change your API Urls in the components/APIKey file where i have exported API Urls.

